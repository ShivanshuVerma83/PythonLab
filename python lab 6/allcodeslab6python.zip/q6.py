def fun():
    var1 = input("Enter the first string in ineger form: ")
    var2 = input("Enter the second stringin integer form: ")

    var3 = int(var1) + int(var2)
    print(var3)
fun()