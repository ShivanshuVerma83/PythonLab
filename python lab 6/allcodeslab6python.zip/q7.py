def fun():
    var1 = input("Enter the first string: ")
    var2 = input("Enter the second string: ")

    var3 = var1 + var2
    print(var3)
fun()