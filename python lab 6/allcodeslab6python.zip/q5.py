def fun():
    a = int(input("Enter the first number: "))
    b = int(input("Enter the second number: "))

    c = int(a) + int(b)
    print(c)
fun()