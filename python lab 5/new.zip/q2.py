list1 = [10,20,30,50,50,60]


set1= set(list1)


print(set1)