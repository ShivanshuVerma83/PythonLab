s = input("please enter the values: ")
t= input("please enter the other values: ")
str_set = set(s)
str_set2=set(t)
print('Union is:',str_set|str_set2)
print('intersection is', str_set&str_set2)

