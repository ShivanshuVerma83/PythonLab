# class shivanshu:
#     a=0 #class attribute
#     def count(self):
#         shivanshu.a+=2
#
# # calling function
# #created an instance p
#
# p=shivanshu()
# p.count()
# print(p.a)


 #created object
class Shinu:
    def __init__(self, name, age):
        self.name = name
        self.age = age
#instance of class
new_shark = Shinu("Shivanshu", 18)
print(new_shark.name)
print(new_shark.age)



