import random
l = ["quote "+str(i) for i in range(1,8)]
print(l[random.randint(1,7)])
