d=dict()
for x in range(1,11):
    d[x]=x**2
print(d)