a=range(1,101)
k=sum(a)

print(k*k-sum(l*l for l in a))