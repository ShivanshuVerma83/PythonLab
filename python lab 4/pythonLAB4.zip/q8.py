n = 1
d = dict(input("Enter name and value: ").split() for _ in range(n))

dict1 = d
n = 1
e = dict(input("Enter designation and value: ").split() for _ in range(n))

dict2 = e
n = 1
d = dict(input("Enter salary and value: ").split() for _ in range(n))

dict3 = d

Employee = {1: dict1,
          2: dict2,
          3: dict3}
# manager = {1: dict1,
#           2: dict2,
#           3: dict3}
# associate = {1: dict1,
#           2: dict2,
#           3: dict3}
# Employee ={1: officer,
#            2: manager,
#            3: associate}
print(Employee)